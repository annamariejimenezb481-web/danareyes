# 1482 Alder Lane — Two-page property website

## Files
- `index.html`: property listing
- `blog.html`: original blog post, unchanged in its article body
- `style.css`: design and mobile styles
- `script.js`: mobile menu and image gallery viewer
- `images/`: five uploaded property photos
- `alder-lane-model-blog-post.txt`: original source text, retained unchanged

## Preview locally
Extract the ZIP and open `index.html` in a browser. Select **Blog** to check the second page. Keep the images folder alongside the HTML files.

## Deploy on Netlify
1. Sign in to Netlify.
2. Go to **Add new project** > **Deploy manually** (labels may vary).
3. Drag the extracted `alder-lane-website` folder into the deployment area, or upload the folder as instructed. Do not upload just the HTML file.
4. Wait for the deploy to finish, then test the listing, blog, image viewer, menu and phone link.

## Deploy on Vercel
1. Create a new GitHub repository.
2. Upload the contents of `alder-lane-website` to the repository root (so `index.html` is at the top level).
3. In Vercel, select **Add New** > **Project**, then import that repository.
4. Use framework preset **Other** (static site), no build command, and output directory `.` if asked.
5. Click **Deploy** only when you are ready to publish.
6. Test `/` and `/blog.html` and confirm all photos load.

## Important
The original blog text is preserved verbatim, including its past-tense-sensitive open-house invitation. A separate date notice is shown above the article because October 10, 2026 has passed. No upcoming open house is advertised elsewhere. The uploaded photographs are used as supplied. Confirm that they depict this listing and that you have permission to publish them. Confirm current listing status before going live. The phone link uses the provided contact number. Instagram captions do not generally support clickable external links: share the deployed URL in your Instagram bio or story link sticker.
